ASEkit is a convenient tool  that you can be easily to call ASE and assocaiting it with candidate regultory SNP and trait

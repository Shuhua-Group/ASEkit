ASEkit Filter \
	--rawdir ./example.data/ \
   --totalreads 10 --fdr 0.05 --AIvalue 0.2 \
	--sample sample.info.txt \
    --outdir out


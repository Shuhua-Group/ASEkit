import os
test_filepath=os.path.join(os.path.split(os.path.realpath(__file__))[0],'example.fromat.data')
#filepath=os.path.join(os.path.split(os.path.realpath(__file__))[0],'src/phaser.py')
print('test data filepath: '+test_filepath)


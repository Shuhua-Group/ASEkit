ASEkit Filter --rawdir ./example.data/ \
   --totalreads 10 --fdr 0.05 --AIvalue 0.2 \
	--sample sample.info.txt

##python3 /picb/humpopg-bigdata5/huangke/research/ASEtools/new/ASEkit/ASEkit/ASEfilter.py  Filter --rawdir /picb/humpopg-bigdata5/huangke/research/ASEtools/v2/ASE_calling_out  \

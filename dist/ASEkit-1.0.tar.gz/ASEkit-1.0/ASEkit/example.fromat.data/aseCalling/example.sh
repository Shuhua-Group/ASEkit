ASEkit Calling \
	--sample ./sample.info.txt \
	--rnaseq ./RNA_test_data \
	--vcf ./vcf_test_data \
	--process 4

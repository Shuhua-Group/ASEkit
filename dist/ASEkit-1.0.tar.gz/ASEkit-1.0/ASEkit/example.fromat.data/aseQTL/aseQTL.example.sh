ASEkit aseQTL --ase population.ase.test.txt \
	--vcf vcf_filepath.txt \
	--hetNumber 8 \
	--cisRegion 100000 \
	--process 2 \
	--out ./ASE.res

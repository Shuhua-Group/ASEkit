ASEkit aseTrait --ase population.ase.test.txt \
	--pheno pheno.test.txt \
	--outdir res_out

ASEkit aseQTL  \
   --ase population.ase.chr.test.txt \
   	--vcf vcf_filepath.txt \
	--hetNumber 8 \
	--cisRegion 100000 \
	--process 2 \
	--outdir ./ASE.res
